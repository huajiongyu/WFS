﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WFS.Models
{
    public class JsonResultModel
    {
        public bool success { get; set; }
        public string message { get; set; }
    }
}